var zf_isMobile;

jQuery(document).ready(function ($) {

    responsive();

    /** Detect Device Type */
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        zf_isMobile = true;
        jQuery('html').addClass('zf-mobile');
    } else {
        zf_isMobile = false;
        jQuery('html').addClass('zf-desktop');
    }


    jQuery(".zombify_quiz").on("change", "input[type='file']", function(e){
        if( !ZombifyBuilder.validateField( jQuery(this) ) ) {
            jQuery(this).val('');
        } else {

            zombify_virtual_unsaved_form = true;

            if( jQuery(this).attr("data-zombify-field-type") == 'file' ){

                jQuery(this).attr("data-zf-file-browsed", "1");

                ZombifyBuilder.virtualSave();

            }

        }
    });


    jQuery(document).on("click", ".zf-submit_url", function(){

        ZombifyBuilder.virtualSave();

    });

    jQuery(document).on('click', ".zf-uploader .js-zf-get_url", function (e) {
        e.stopPropagation();
        e.preventDefault();
        jQuery(this).parents('.zf-uploader').find('.zf-get-url-popup').addClass('zf-open');
        jQuery(this).parents('.zf-uploader').find('.zf-image_url,.zf-start-image_url').focus();
    });
    jQuery(document).on('click', ".zf-uploader .zf-popup-close", function (e) {
        e.stopPropagation();
        e.preventDefault();
        jQuery(this).parents('.zf-uploader').find('.zf-get-url-popup').removeClass('zf-open');
    });
    jQuery(document).on('click', ".zf-uploader .zf-submit_url", function (e) {
        jQuery(this).parents('.zf-uploader').find('.zf-preview-gif').hide();
        zf_get_video_by_url( this );
    });

    jQuery(".zf-uploader .zf-submit_url").each(function(){

        zf_get_video_by_url( this );

    });


    /** Open list/Ranked List voting  (up) */
    jQuery(document).on("click", ".zf-vote_up", function(){

        jQuery(this).parent().addClass('zf-loading');

        var zf_post_id = jQuery(this).parent().attr("data-zf-post-id");
        var zf_post_parent_id = jQuery(this).parent().attr("data-zf-post-parent-id");

        jQuery.ajax({
            url: zf.ajaxurl,
            type: 'POST',
            data: {post_id: zf_post_id, post_parent_id: zf_post_parent_id, vote_type: 'up', action: 'zombify_post_vote'},
            dataType: 'json',
            success: function (data) {
                jQuery(".zf-vote_count[data-zf-post-id='"+data.post_id+"'] .zf-vote_number").html( data.votes );
                jQuery(".zf-vote_count[data-zf-post-id='"+data.post_id+"']").parent().removeClass('zf-loading');
            }
        });

    });

    /** Open list/Ranked List voting  (down) */
    jQuery(document).on("click", ".zf-vote_down", function(e){

        jQuery(this).parent().addClass('zf-loading');

        var zf_post_id = jQuery(this).parent().attr("data-zf-post-id");
        var zf_post_parent_id = jQuery(this).parent().attr("data-zf-post-parent-id");

        jQuery.ajax({
            url: zf.ajaxurl,
            type: 'POST',
            data: {post_id: zf_post_id, post_parent_id: zf_post_parent_id, vote_type: 'down', action: 'zombify_post_vote'},
            dataType: 'json',
            success: function (data) {
                jQuery(".zf-vote_count[data-zf-post-id='"+data.post_id+"'] .zf-vote_number").html( data.votes );
                jQuery(".zf-vote_count[data-zf-post-id='"+data.post_id+"']").parent().removeClass('zf-loading');
            }
        });

    });

    /** Comments load more  */
    jQuery('.zf-comments_load_more a').on('click',function(e){
        e.preventDefault();
        var _this  = jQuery(this),
            page = parseInt(_this.attr('data-page')),
            count = _this.data('pages-count');


        _this.parent().addClass('zf-loading');

        jQuery.ajax({
            url: zf.ajaxurl,
            type: 'POST',
            data: {post_id: _this.data('post-id'), page: page, action: 'zombify_get_post_comments'},
            dataType: 'json',
            success: function (data) {
                jQuery('[data-post-id='+_this.data('post-id')+'] .zf-comments-box').append(data.comments);

                _this.attr('data-page', page + 1);

                if (count + 1 <= page + 1) _this.parent().addClass('zf-hide');
                _this.parent().removeClass('zf-loading');
            }
        });
    });

    /** Tabs */
    var tabActive = jQuery('.tabs-menu>li.active');
    if( tabActive.length > 0 ){
        for (var i = 0; i < tabActive.length; i++) {
            var tab_id = jQuery(tabActive[i]).children().attr('href');

            jQuery(tab_id).addClass('active').show();
        }
    }

    jQuery('.zf-tabs-menu a').on('click', function(e){
        var tab = jQuery(this);
        var tab_id = tab.attr('href');
        var tab_wrap = tab.closest('.zf-tabs');
        var tab_content = tab_wrap.find('.zf-tab-content');

        tab.parent().addClass("zf-active");
        tab.parent().siblings().removeClass('zf-active');
        tab_content.not(tab_id).removeClass('zf-active').hide();
        jQuery(tab_id).addClass('zf-active').fadeIn(500);

        e.preventDefault();
    });

    parseAllEmbed();

    if( jQuery('.fb-video').length > 0 || jQuery('.fb-post').length > 0 ) {

        facebookEmbedScript();

    }

});

function responsive() {
    var container = jQuery('.zombify-screen'),
        screenWidth = container.width();

    switch (true) {
        case screenWidth > 850:
            container.removeClass(function (index, css) {
                return (css.match(/(^|\s)zf-screen-\S+/g) || []).join(' ');
            });
            container.addClass('zf-screen-lg');
            break;

        case screenWidth <= 850 && screenWidth > 700:
            container.removeClass(function (index, css) {
                return (css.match(/(^|\s)zf-screen-\S+/g) || []).join(' ');
            });
            container.addClass('zf-screen-md');
            break;

        case screenWidth <= 700 && screenWidth > 550:
            container.removeClass(function (index, css) {
                return (css.match(/(^|\s)zf-screen-\S+/g) || []).join(' ');
            });
            container.addClass('zf-screen-sm');
            break;

        case screenWidth <= 550:
            container.removeClass(function (index, css) {
                return (css.match(/(^|\s)zf-screen-\S+/g) || []).join(' ');
            });
            container.addClass('zf-screen-xs');
            break;
    }

    /**
     *
     * Zombify Post Types
     *
     * ***/

    // Personality Quiz Post Type
    personalityPostType();

    // Trivia Quiz Post Type
    triviaPostType();

    // Poll Post Type
    pollPostType();

    // Open Post Type new content upload
    openListUploader();

    // Before - After Slider Post Type
    beforeAfterPostType();

    jQuery(document).on("change", ".zf-image_url", function(){

        jQuery(this).closest(".zf-uploader").closest(".zf-form-group").find(".zf-help").remove();

    });
}

function personalityPostType() {

    jQuery('.zf-personality_quiz').each(function(){
        var quizContainer = jQuery(this);

        var personalAllow = true;
        quizContainer.find('.zf-quiz_answer .zf-answer .zf-answer_credit').on('click', function (e) {
            e.stopPropagation();
        });
        quizContainer.find('.zf-quiz_answer .zf-answer').on('click', function () {
            if (personalAllow) {
                var _this = jQuery(this);
                _this.parent().find('.zf-selected').removeClass('zf-selected');
                _this.parent().find('.zf-deactivated').removeClass('zf-deactivated');
                _this.addClass('zf-selected');
                _this.parent().find('li').not('.zf-selected').addClass('zf-deactivated');
                _this.parent().addClass('zf-choice');
                _this.parent().parent().addClass('zf-done');


                if (quizContainer.find('.zf-choice').length == quizContainer.data('question_count')) {
                    personalAllow = false;

                    var resultsCount = quizContainer.data('result_count');
                    var results = [];

                    for (var i = 0; i <= resultsCount; i++) {
                        var qnt = quizContainer.find('.zf-selected[data-personality_index=' + i + ']').length;
                        results.push(qnt);
                    }

                    var max = results[0];
                    var maxIndex = 0;

                    for (var i = 1; i < results.length; i++) {
                        if (results[i] > max) {
                            maxIndex = i;
                            max = results[i];
                        }
                    }
                    quizContainer.find(".zf-quiz_results").show();
                    quizContainer.find(".zf-quiz_results ol li:nth-child(" + (maxIndex + 1) + ")").show();

                    var pos = quizContainer.find('.zf-quiz_results').offset();
                    jQuery('body,html').animate({
                        scrollTop: pos.top - 150
                    }, 500);
                } else if (_this.parent().parent().index() + 1 == quizContainer.data('question_count')) {

                    var pos = quizContainer.find('.zf-quiz_question').not('.zf-done').offset();

                    jQuery('body,html').animate({
                        scrollTop: pos.top - 150
                    }, 500);

                } else {
                    var pos = _this.parent().parent().next().offset();

                    jQuery('body,html').animate({
                        scrollTop: pos.top - 150
                    }, 500);
                }
            }

        });
    })
}


function triviaPostType(){
    jQuery('.zf-trivia_quiz .zf-quiz_answer .zf-answer').on('click', function () {

        var _this = jQuery(this),
            _parent = _this.parents('.zf-trivia_quiz');

        var triviaAllow = true;
        var showAnswer = false;

        if (_parent.hasClass('zf-show-answer')) {
            showAnswer = true;
        }

        _parent.find('.zf-quiz_answer .zf-answer .zf-answer_credit').on('click', function (e) {
            e.stopPropagation();
        });

        if (triviaAllow) {
            if (!_this.parent().hasClass('zf-choice')) {
                _this.parent().find('.zf-selected').removeClass('zf-selected');
                _this.parent().find('.zf-deactivated').removeClass('zf-deactivated');
                _this.addClass('zf-selected');
                _this.parent().find('li').not('.zf-selected').addClass('zf-deactivated');
                _this.parent().addClass('zf-choice');
                _this.parent().parent().addClass('zf-done');

                if (showAnswer) {
                    if (_this.data('correct') == 1) {
                        _this.parent().parent().find('.zf-quiz_reveal .zf-reveal_header').addClass('zf_correct');
                    } else {
                        _this.parent().parent().find('.zf-quiz_reveal .zf-reveal_header').addClass('zf_wrong');
                    }
                    _this.parent().parent().find('.zf-quiz_reveal').show();
                }
            }

            if (_parent.find('.zf-choice').length == _parent.data('question_count')) {
                _parent.addClass('zf-quiz-done');
                triviaAllow = false;

                var questionCount = _parent.data('question_count');
                var correctAnswerCount = _parent.find('li.zf-selected[data-correct="1"]').length;


                _parent.find('.zf-quiz_results li').each(function () {
                    var rangeStart = jQuery(this).data('range_start');
                    var rangeEnd = jQuery(this).data('range_end');

                    if (correctAnswerCount >= rangeStart && correctAnswerCount <= rangeEnd) {
                        jQuery(this).find('.zf-score_count').text(correctAnswerCount + '/' + questionCount);
                        jQuery(this).find('.zf-score_count_currect').text(correctAnswerCount);
                        jQuery(this).show();
                        // add result to Twitter share
                        var tw = jQuery(this).find('.zf-share.zf_twitter').attr('href');
                        var new_tw = tw.replace("zombifyResult", correctAnswerCount + '/' + questionCount);
                        jQuery(this).find('.zf-share.zf_twitter').attr('href', new_tw);
                        // add result to Facebook share
                        var fb = jQuery(this).find('.zf-share.zf_facebook').attr('href');
                        var new_fb = fb.replace("zombifyResult", correctAnswerCount + '/' + questionCount);
                        jQuery(this).find('.zf-share.zf_facebook').attr('href', new_fb);

                        // Show correct result
                        _parent.find('.zf-quiz_results').show();
                        var pos = _parent.find('.zf-quiz_results').offset();
                        jQuery('body,html').animate({
                            scrollTop: pos.top
                        }, 500);
                    }
                })
            } else if (_this.parent().parent().index() + 1 == _parent.data('question_count')) {

                var pos = _parent.find('.zf-quiz_question').not('.zf-done').offset();

                jQuery('body,html').animate({
                    scrollTop: pos.top - 150
                }, 500);

            }
        }
    });
}

function pollPostType(){
    jQuery('.zf-poll-item').each(function(){

        var pollContainer = jQuery(this);

        var pollAllow = true,
            totalVoted = pollContainer.data('voted_count');

        if (pollContainer.hasClass('zf-poll-done')) {
            pollAllow = false;
            pollStat(pollContainer.find('.zf-quiz_answer'), totalVoted);
        }

        pollContainer.find('.zf-answer .zf-answer_credit').on('click', function (e) {
            e.stopPropagation();
        });
        pollContainer.find('.zf-answer').on('click', function () {
            if (pollAllow) {
                var  _this = jQuery(this), singleVoted = _this.data('voted'), id = _this.data('id'), post_id = _this.data('post-id'), group_id = _this.data('group-id');
                _this.addClass('zf-selected');
                //pollAllow = false;
                totalVoted++;
                _this.attr('data-voted', singleVoted + 1);
                pollContainer.find('.voted-count').html(totalVoted);

                pollStat(_this.parent(), totalVoted);

                pollContainer.addClass('zf-poll-done');


                var shareText = jQuery.trim(pollContainer.find('.zf-selected .zf-answer_text').text());
                // add result to Twitter share
                var tw = pollContainer.find('.zf-share.zf_twitter').attr('href');
                var new_tw = tw.replace("zombifyResult", shareText);
                pollContainer.find('.zf-share.zf_twitter').attr('href', new_tw);
                // add result to Facebook share
                var fb = pollContainer.find('.zf-share.zf_facebook').attr('href');
                var new_fb = fb.replace("zombifyResult", shareText);
                pollContainer.find('.zf-share.zf_facebook').attr('href', new_fb);



                jQuery.ajax({
                    url: zf.ajaxurl + '?action=poll_vote',
                    type: 'POST',
                    data: {id: id, post_id: post_id, group_id: group_id, action: 'zombify_poll_vote'},
                    dataType: 'json',
                    success: function (data) { }
                });
                pollAllow = false;
            }
        });

        var shareText = jQuery.trim(pollContainer.find('.zf-selected .zf-answer_text').text());

        if( shareText!='' ) {

            // add result to Twitter share
            var tw = pollContainer.find('.zf-share.zf_twitter').attr('href');
            var new_tw = tw.replace("zombifyResult", shareText);
            pollContainer.find('.zf-share.zf_twitter').attr('href', new_tw);
            // add result to Facebook share
            var fb = pollContainer.find('.zf-share.zf_facebook').attr('href');
            var new_fb = fb.replace("zombifyResult", shareText);
            pollContainer.find('.zf-share.zf_facebook').attr('href', new_fb);

        }
    });
}

function openListUploader(){
    jQuery('.zf-media-uploader.zf-openlist').each(function(){
        var openListUploader = jQuery(this);

        openListUploader.find('input[type="file"]').on('change',function(){
            openListUploader.find('.zf-hide').removeClass('zf-hide');
        });
        openListUploader.find('.zf-submit_url').on('click',function(){
            openListUploader.find('.zf-hide').removeClass('zf-hide');
        });

        openListUploader.find('.zombify_embed_url_textarea').on("keyup", function () {
            openListUploader.find('.zf-hide').removeClass('zf-hide');
        });
    })
}

function beforeAfterPostType() {
    jQuery('.zf-js-before-after-slider').each(function(){
        var _this = jQuery(this),
            contWidth = _this.width(),
            after = _this.find('.zf-after'),
            before = _this.find('.zf-before');

        _this.find('img').css('max-width',contWidth + 'px');

        _this.on('mousemove', function(e) {
            e.preventDefault();
            moveHandler(_this, e);
        });

        var lastTouchX = null;

        _this.on('touchstart', function(e) {
            var touch = e.originalEvent.touches[0] || e.originalEvent.changedTouches[0];

            lastTouchX = touch.pageX;
        });

        _this.on('touchend', function(e) {
            lastTouchX = null;
        });

        _this.on('touchmove', function(e) {
            var touch = e.originalEvent.touches[0] || e.originalEvent.changedTouches[0];

            var deltaX = touch.pageX - parseInt(lastTouchX, 10);

            if (deltaX) {
                moveHandler(_this, touch);
            }
        });

    });
}

function facebookEmbedScript() {
    try {
        if( jQuery('#fb-root').length == 0 ) {
            jQuery('body').prepend('<div id="fb-root"></div><script>(function(d, s, id) { var js, fjs = d.getElementsByTagName(s)[0]; if (d.getElementById(id)) {return}; js = d.createElement(s); js.id = id; js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.6"; fjs.parentNode.insertBefore(js, fjs); }(document, "script", "facebook-jssdk"));</script>');
        }

        FB.XFBML.parse();
    } catch (e) {}
}

function pollStat(obj, total) {

    obj.find('[data-voted]').each(function () {
        var count = jQuery(this).attr('data-voted');
        var percent = Math.round((count * 100) / total);
        jQuery(this).find('.zf-poll-stat_count').html(percent + '%');
        jQuery(this).find('.zf-poll-stat').css({
            'height': percent + '%',
            'width': percent + '%'
        });
    })
}

String.prototype.splice = function(idx, rem, str) {
    return this.slice(0, idx) + str + this.slice(idx + Math.abs(rem));
};

function moveHandler(obj, e) {
    var offset = obj.offset();
    var iTopWidth = (e.pageX - offset.left);

    // set width of bottomimage div
    obj.find('.zf-before').width(iTopWidth);
    obj.find('.zf-hint').remove();
}

// ZombifyOnAjax when using dynamic content
// This function call all functions that need to recall after dynamic content load
function ZombifyOnAjax() {

    parseAllEmbed();
    personalityPostType();
    triviaPostType();
    pollPostType();
    openListUploader();
}


function parseAllEmbed(){

    jQuery(".zombify_quiz :input[data-embed-url='1']").each(function(){

        var videoObj = parseEmbedURL(jQuery(this), jQuery(this).val(), '100%', 300, jQuery(this).attr("data-embed-sources"), 0 );

        jQuery(this).closest(".zf-embed").find(".zf-embed-video").html( videoObj.html );

        if( videoObj.type == 'mp4' ){

            var video = jQuery(this).closest(".zf-embed").find(".zf-embed-video").find("video");

            window.ZFMediaElementPlayer = new MediaElementPlayer(video);

        }

    });

    jQuery(".zf-embedded-url").not('.zf-embedded-url.zf-done').each(function () {

        var videoObj = parseEmbedURL(jQuery(this), jQuery(this).html(), '100%', 500);

        jQuery(this).html(videoObj.html);
        jQuery(this).attr('data-zf-embed-type', videoObj.type).addClass('zf-done');

        if( videoObj.type == 'mp4' ){

            var video = jQuery(this).find("video");

            window.ZFMediaElementPlayer = new MediaElementPlayer(video);

        }

    });

}


function parseEmbedURL(obj, url, width, height, sources, chng){

    if( typeof chng == 'undefined' ) chng = 0;

    var valid_sources = new Array();

    if( typeof sources != 'undefined' && sources != '' )
        valid_sources = sources.split(",");

    jQuery(obj).closest(".zf-embed").find("input[data-zombify-field-name='embed_thumb']").val('');

    var output          = '',
        type            = '',
        imgur_param     = '',
        reddit_url_left = '',
        reddit_username = '',
        temp_url        = '',
        multy_url       = '';

    if( temp_url = url.match(/(http:|https:|)\/\/(www.)?[A-Za-z0-9._%-]{1,}.[A-Za-z0-9._%-]{1,}[/A-Za-z0-9._%-]{1,}([?][^ "]{1,})?/g) ) {

        url = url.match(/(http:|https:|)\/\/(www.)?[A-Za-z0-9._%-]{1,}.[A-Za-z0-9._%-]{1,}[/A-Za-z0-9._%-]{1,}([?][^ "]{1,})?/g)[0];

        if( url.indexOf('href=') > -1 ) {

            url = decodeURIComponent(url);

            multy_url = url.split("href=");

            url = multy_url[1];

        } else if( url.indexOf('url=') > -1 ) {

            url = decodeURIComponent(url);

            multy_url = url.split("url=");

            url = multy_url[1];

        } else if( url.indexOf('feed=') > -1 ) {

            url = decodeURIComponent(url);

            multy_url = url.split("feed=");

            url = multy_url[1];

        }

        jQuery(obj).val(url);

    }

    if ( url != '' && !url.match(/(http:|https:|)\/\//i) ) {
        if( url.match(/soundcloud/) || url.match(/facebook/) ) {
            url = "https://" + url;
        } else {
            url = "//" + url;
        }
    }

    url.match(/(http:|https:|)\/\/([A-Za-z0-9._%-]*.)?(vimeo\.com|youtu(be\.com|\.be|be\.googleapis\.com)|instagram\.com|vine\.co|pinterest\.com|twitter\.com|t\.co|google\.[a-z]{0,4}|mixcloud\.com|soundcloud\.com|dailymotion\.com|coub\.com|vid\.me|imgur\.com|reddit\.com|facebook\.com|twitch\.tv)\/(video\/|embed\/|watch\?v=|v\/|p\/|pin\/|[A-Za-z0-9.\-_%]*\/status\/|maps\/place\/)?([A-Za-z0-9._,%\-\+]*)([\/\@]*)([A-Za-z0-9._,%-\+]*)(\&\S+)?/);

    if (RegExp.$3.indexOf('youtu') > -1) {
        type = 'youtube';
    }
    else if (RegExp.$3.indexOf('vimeo') > -1) {
        type = 'vimeo';
    }
    else if (RegExp.$3.indexOf('instagram') > -1) {
        type = 'instagram';
    }
    else if (RegExp.$3.indexOf('pinterest') > -1) {
        type = 'pinterest';
    }
    else if (RegExp.$3.indexOf('twitter') > -1) {
        type = 'twitter';
    }
    else if (RegExp.$3.indexOf('google') > -1) {
        type = 'google';

        var url_parts  = url.split("/");
        var url_params = url_parts[url_parts.length-1];

        url_params = url_params.split(",");
    }
    else if (RegExp.$3.indexOf('soundcloud') > -1) {
        type = 'soundcloud';
    }
    else if (RegExp.$3.indexOf('mixcloud') > -1) {
        type = 'mixcloud';
    }
    else if (RegExp.$3.indexOf('dailymotion') > -1) {
        type = 'dailymotion';
    }
    else if (RegExp.$3.indexOf('vine') > -1) {
        type = 'vine';
    }
    else if(url.indexOf('coub.com/embed') > -1) {
        type = 'coub_embed';
    }
    else if (RegExp.$3.indexOf('coub') > -1) {
        type = 'coub';
    }
    else if (RegExp.$3.indexOf('imgur') > -1) {
        type = 'imgur';
    }
    else if (url.indexOf('vid.me/e') > -1) {
        type = 'vidme_embed';
    }
    else if (RegExp.$3.indexOf('vid') > -1) {
        type = 'vidme';
    }
    else if (RegExp.$3.indexOf('facebook') > -1) {
        type = 'facebook';
    }
    else if (RegExp.$3.indexOf('reddit') > -1) {
        reddit_url_left = RegExp.$6 + '/' + RegExp.$8;
        reddit_username = RegExp.$8;
        type = 'reddit';
    } else if (RegExp.$3.indexOf('t.co') > -1) {
        type = 'twitter_embed';
        url = temp_url[1];
        jQuery(obj).val(url);
    } else if (RegExp.$3.indexOf('twitter') > -1) {
        type = 'twitter';
    } else if (RegExp.$3.indexOf('twitch') > -1) {
        type = 'twitch';
    } else {

        var re = /(?:\.([^.]+))?$/;

        var ext = re.exec( url );

        if( typeof ext != 'undefined' && typeof ext[1] != 'undefined' ){

            type = ext[1].toLowerCase();

        }

    }

    if( valid_sources.length > 0 && !valid_sources.contains(type) )
        return {
            type: '',
            id: '',
            html: ''
        };

    var thumb = '';

    var video_id = RegExp.$6;

    if( type == 'dailymotion' ){

        video_id = video_id.substring( 0, video_id.indexOf("_") );

    } else if ( type == 'coub_embed' ) {

        video_id = RegExp.$6;

    } else if ( type == 'coub' ) {

        video_id = RegExp.$8;

    } else if ( type == 'imgur' && url.indexOf('gallery') !== -1 ) {

        video_id = RegExp.$8;

    } else if ( type == 'facebook' ) {

        var fb_url = url;
        var fb_type = RegExp.$8;

        if(url.indexOf('fbid') !== -1) {
            fb_type = 'post';
        }

        if( fb_type === 'videos' ) {
            fb_type = 'video';
        } else if( fb_type === 'posts' || fb_type === 'photos' ) {
            fb_type = 'post';
        }

    } else if ( type == 'twitch' ) {

        var video_type = '';

        if( video_id === 'videos' ) {

            video_id = RegExp.$8;
            video_type = 'video';

        }

    } else if ( type == 'twitter_embed' ) {

        var url_parts   = url.split("/");
        var video_id    = url_parts[url_parts.length-1];

    } else if ( type == 'vidme_embed' ) {

        video_id = RegExp.$8;

    }

    var iframe = jQuery('<iframe>', { width: width, height: height });

    iframe.attr('frameborder', 0);

    if (type == 'youtube') {

        video_id = video_id.substr(0, ( video_id.indexOf("&") > -1 ? video_id.indexOf("&") : video_id.length ));

        iframe.attr('src', '//www.youtube.com/embed/' + video_id);
        iframe.attr('allowfullscreen', true);
        output = jQuery(iframe);

        thumb = "https://img.youtube.com/vi/"+video_id+"/0.jpg";
        jQuery(obj).closest(".zf-embed").find("input[data-zombify-field-name='embed_thumb']").val(thumb);

    } else if (type == 'vimeo') {

        iframe.attr('src', '//player.vimeo.com/video/' + video_id);
        output = jQuery(iframe);

        jQuery.ajax({
            type:'GET',
            url: 'http://vimeo.com/api/v2/video/' + video_id + '.json',
            jsonp: 'callback',
            dataType: 'jsonp',
            async: false,
            success: function(data){
                thumb = data[0].thumbnail_large;
                if( thumb != '' )
                    jQuery(obj).closest(".zf-embed").find("input[data-zombify-field-name='embed_thumb']").val(thumb);
            }
        });

    } else if (type == 'instagram') {

        jQuery.ajax({
            type: 'GET',
            url: 'https://api.instagram.com/oembed?url=http://instagr.am/p/' + video_id + '/&callback=?',
            dataType: 'jsonp',
            jsonp: 'callback',
            async: false,
            success: function(data){
                if( typeof data.html != 'undefined' && data.html != '' ) {

                    var data_html = data.html.replace('<script async defer src="//platform.instagram.com/en_US/embeds.js"></script>','');

                    //code for backend
                    if( jQuery(obj).closest(".zf-embed").find(".zf-embed-video").length > 0 ) {

                        jQuery(obj).closest(".zf-embed").find(".zf-embed-video").html(data_html);

                    }

                    //code for frontend
                    if( jQuery('.zf-embedded-url.zf-done[data-zf-embed-type="instagram"]').length > 0 ) {

                        if( jQuery(obj).prop('data-zf-embed-type', 'instagram') ) {

                            jQuery(obj).html(data_html);

                        }

                    }

                    jQuery('script[url="//platform.instagram.com/en_US/embeds.js"]').remove();

                    if( jQuery(obj).closest(".zf-embed").find(".zf-embed-video").length > 0 || jQuery('.zf-embedded-url.zf-done[data-zf-embed-type="instagram"]').length > 0 ) {

                        if( jQuery('script[src="//platform.instagram.com/en_US/embeds.js"]').length == 0 ) {

                            jQuery('body').append('<script async defer src="//platform.instagram.com/en_US/embeds.js"></script>');

                        }

                    }

                    try {

                        if( jQuery(obj).closest(".zf-embed").find(".zf-embed-video").length > 0 || jQuery('.zf-embedded-url.zf-done[data-zf-embed-type="instagram"]').length > 0 ) {
                            window.instgrm.Embeds.process()
                        }

                    } catch (e) {}
                }

            }
        });

    } else if (type == 'vine') {

        iframe.attr('src', 'https://vine.co/v/'+video_id+'/embed/simple');
        output = jQuery(iframe);

        jQuery.ajax({
            type:'POST',
            url: zf.ajaxurl + '?action=zombify_get_vine_thumbnail',
            data: {url: url},
            dataType: 'json',
            async: false,
            success: function(data){
                if( typeof data.thumbnail_url != 'undefined' && data.thumbnail_url != '' )
                    jQuery(obj).closest(".zf-embed").find("input[data-zombify-field-name='embed_thumb']").val(data.thumbnail_url);
            }
        });

    } else if( type == 'coub' || type == 'coub_embed' ) {

        iframe.attr('src', '//coub.com/embed/'+video_id+'?muted=false&autostart=false&originalSize=false&startWithHD=false');
        output = jQuery(iframe);

    } else if(type == 'vidme' || type == 'vidme_embed') {

        iframe.attr('src', 'https://vid.me/e/'+video_id+'?stats=1');
        output = jQuery(iframe);

    } else if (type == 'imgur') {

        if( video_id.length == 5 ) {
            imgur_param = 'a/';
        } else {
            imgur_param = '';
        }
        output = '<blockquote class="imgur-embed-pub" lang="en" data-id="'+imgur_param+video_id+'"><a href="//imgur.com/'+video_id+'">View post on imgur.com</a></blockquote><script async src="//s.imgur.com/min/embed.js" charset="utf-8"></script>';

    } else if( type == 'reddit' ) {

        output = '<blockquote class="reddit-card"><a href="'+url+'?ref=share&ref_source=embed"></a> from <a href="http://www.reddit.com/'+reddit_url_left+'"></a></blockquote><script async src="//embed.redditmedia.com/widgets/platform.js" charset="UTF-8"></script>';

    } else if ( type == 'facebook' ) {

        fb_url = fb_url.replace('/&','?&');

        output  =  '<div class="fb-' + fb_type + '" data-href="' + fb_url + '" data-show-text="false"><div class="fb-xfbml-parse-ignore"><blockquote cite="' + fb_url + '"></blockquote></div></div>';

    } else if (type == 'google') {

        iframe.attr('src', 'https://www.google.com/maps/embed/v1/place?key=AIzaSyAEQaPbp2TE1pEoYbkAE8le5IscUDXtg8Y&center='+url_params[0].replace('@','')+','+url_params[1]+'&zoom='+( url_params[2].replace('z','') )+'&q='+video_id);
        output = jQuery(iframe);

    } else if (type == 'soundcloud') {

        jQuery.ajax({
            url: 'https://soundcloud.com/oembed?format=json&iframe=true&auto_play=false&show_comments=false&url='+url,
            type: 'GET',
            dataType: 'json',
            async: false,
            success: function(data){
                output = data.html;
            }});

    } else if (type == 'mixcloud') {

        output = '<iframe width="100%" height="120" src="https://www.mixcloud.com/widget/iframe/?feed='+url+'&hide_cover=1&light=1" frameborder="0"></iframe>';

    } else if (type == 'dailymotion') {

        output = '<iframe frameborder="0" width="100%" height="300" src="//www.dailymotion.com/embed/video/'+video_id+'" allowfullscreen></iframe>';

    } else if (type == 'pinterest') {

        output = '<a data-pin-do="embedPin" data-pin-width="large" href="https://www.pinterest.com/pin/'+video_id+'/"></a><script async defer src="//assets.pinterest.com/js/pinit.js"></script>';

    } else if (type == 'twitter' || type == 'twitter_embed') {

        var elemID = 'tweet_'+Math.floor((Math.random() * 100000) + 1);
        output = '<div id="'+elemID+'"></div><script>twttr.widgets.createTweet( \''+video_id+'\', document.getElementById(\''+elemID+'\'), { theme: \'light\' } );</script>';

    } else if (type == 'twitch') {

        if( video_type === 'video' ) {

            iframe.attr('src', 'https://player.twitch.tv/?video=v'+video_id+'&autoplay=false');

        } else {

            iframe.attr('src', 'https://player.twitch.tv/?channel='+video_id);

        }

        output = jQuery(iframe);
        iframe.css('height','300px');

    } else if (type == 'gif' || type == 'jpg' || type == 'jpeg' || type == 'png') {

        output = '<img src="'+url+'" alt="" width="100%" height="auto">';

    } else if (type == 'mp4') {

        output = '<video width="'+width+'" height="'+height+'" controls><source src="'+url+'" type="video\/mp4"><\/video>';

    }

    return {
        type: type,
        id: video_id,
        html: type != '' ? output : ''
    };

}