var zombify_unsaved_form = false;
var zombify_virtual_unsaved_form = false;
var zombify_virtual_save_interval_default = 5000;
var zombify_virtual_save_interval_max = 60000 * 20;
var zombify_virtual_save_interval = zombify_virtual_save_interval_default;
var zombify_video_upload = new Array();
var zombify_virtual_addit_data = {};

var zf_wysiwyg_config_advanced = {
    language:                   zf_back.zf_froala_lang,
    heightMin:                  zf_back.zf_editor_settings.zf_editor_adv_height,
    charCounterMax:             zf_back.zf_editor_settings.zf_editor_adv_char_counter_max,
    paragraphFormat:            zf_back.zf_editor_settings.zf_editor_paragraphs,
    placeholderText:            zf_back.zf_editor_settings.zf_editor_adv_placeholder,
    imageDefaultWidth:          zf_back.zf_editor_settings.zf_editor_adv_image_default_width,
    toolbarButtons:             zf_back.zf_editor_settings.zf_editor_adv_toolbar,
    toolbarButtonsMD:           zf_back.zf_editor_settings.zf_editor_adv_toolbar,
    toolbarButtonsSM:           zf_back.zf_editor_settings.zf_editor_adv_toolbar,
    toolbarButtonsXS:           zf_back.zf_editor_settings.zf_editor_adv_toolbar,
    imageManagerPreloader:      zf_back.zf_editor_settings.zf_editor_loader,
    imageUploadParams:          zf_back.zf_editor_image_upload_params,
    imageManagerLoadParams:     zf_back.zf_editor_image_manager_load_params,
    imageUploadURL:             zf_back.zf_editor_image_upload_action,
    imageManagerLoadURL:        zf_back.ajaxurl,
    imageUploadMethod:          'POST',
    imageManagerLoadMethod:     'POST',
    pastePlain:                 zf_back.zf_editor_settings.zf_editor_paste_plain,
    imageMaxSize:               zf_back.zf_max_upload_size,
};
var zf_wysiwyg_config_light = {
    language:                   zf_back.zf_froala_lang,
    heightMin:                  zf_back.zf_editor_settings.zf_editor_lt_height,
    charCounterMax:             zf_back.zf_editor_settings.zf_editor_lt_char_counter_max,
    paragraphFormat:            zf_back.zf_editor_settings.zf_editor_paragraphs,
    placeholderText:            zf_back.zf_editor_settings.zf_editor_lt_placeholder,
    imageDefaultWidth:          zf_back.zf_editor_settings.zf_editor_lt_image_default_width,
    toolbarButtons:             zf_back.zf_editor_settings.zf_editor_lt_toolbar,
    toolbarButtonsMD:           zf_back.zf_editor_settings.zf_editor_lt_toolbar,
    toolbarButtonsSM:           zf_back.zf_editor_settings.zf_editor_lt_toolbar,
    toolbarButtonsXS:           zf_back.zf_editor_settings.zf_editor_lt_toolbar,
    imageManagerPreloader:      zf_back.zf_editor_settings.zf_editor_loader,
    imageUploadParams:          zf_back.zf_editor_image_upload_params,
    imageManagerLoadParams:     zf_back.zf_editor_image_manager_load_params,
    imageUploadURL:             zf_back.zf_editor_image_upload_action,
    imageManagerLoadURL:        zf_back.ajaxurl,
    imageUploadMethod:          'POST',
    imageManagerLoadMethod:     'POST',
    pastePlain:                 zf_back.zf_editor_settings.zf_editor_paste_plain,
    imageMaxSize:               zf_back.zf_max_upload_size,
};

jQuery(document).ready(function ($) {



    window.onbeforeunload = function (e) {

        if (zombify_unsaved_form) {

            e = e || window.event;

            // For IE and Firefox prior to version 4
            if (e) {
                e.returnValue = 'Are you sure you want to exit without saveing?';
            }

            // For Safari
            return 'Are you sure you want to exit without saveing?';

        }
    };


    $(document).on("change", "#zombify-form :input", function () {

        zombify_unsaved_form = true;

    });

    // Correct builder
    ZombifyBuilder.correctBuilder();

    // Zombify Post actions  Save/Preview/Publish
    if ($('#zf-fixed-bottom-pane').length) {

        if ($(window).width() > 700) {

            $('#zf-fixed-bottom-pane').appendTo('body');
        }

        // Event for previewing the Zombify post
        $(document).on("click", ".zombify_preview", function (e) {

            url_post_id = parseInt($('#zombify-form').find(".zombify_post_id").val());

            if (!url_post_id) {
                alert( zf_back.translatable["preview_alert"] );
                e.preventDefault();
                return false;
            }

            if (!$(this).attr("href")) {
                e.preventDefault();
                return false;
            }

        });

        // Event for saveing the Zombify post
        $(document).on("click", ".zombify_save", function (e) {

            e.preventDefault();

            //Preview
            ZombifyBuilder.save($(this));

        });

        // Event for saveing and publishing the Zombify post
        $(document).on("click", ".zombify_publish", function (e) {

            e.preventDefault();

            //Preview
            ZombifyBuilder.save($(this), false, true);

        });
    }

    // Event for adding Zombify group
    $(document).on("click", ".zombify_add_group", function (e) {

        e.preventDefault();

        // Add new group
        ZombifyBuilder.addGroup($(this));

        zf_video_upload_func();

    });

    // Event for adding Zombify group
    $(document).on("click", ".zf-components .zombify_add_group", function (e) {

        $(this).closest('.zf-components').removeClass('zf-open');

    });

    // Event for removing Zombify group
    $(document).on("click", ".zombify_delete_group", function (e) {

        e.preventDefault();

        // Add new group
        ZombifyBuilder.deleteGroup($(this));

    });

    // Event for removing Media
    $(document).on("click", ".zf-remove-media", function (e) {

        e.preventDefault();

        var attach_id = $(this).closest(".zf-uploader").find("input[data-zf-media-id]").attr("data-zf-media-id");

        if( attach_id !== '' ) {

            zombify_virtual_addit_data.attach_id = attach_id;
            zombify_virtual_addit_data.addit_action = "zf_delete_media";

        }

        $(this).closest(".zf-form-group").find(".zombify_uploaded_image_item").remove();

        if( window.ZFMediaElementPlayer !== undefined ) {

            window.ZFMediaElementPlayer.pause();

        } else {
            if( $(this).parents('.zf-uploader').find('div.zf-video-player').length > 0 ) {

                var file = $(this).parents('.zf-uploader').find('div.zf-video-player');

                new MediaElementPlayer(file, {success: function(media) {
                        media.pause();
                    }
                });

            }
        }

        // Delete Media
        ZombifyBuilder.deleteMedia($(this));

        ZombifyBuilder.updateShowDependency();

        ZombifyBuilder.validateFields();

        zombify_virtual_unsaved_form = true;

        $(this).parent().find('input[type="file"]').attr("data-zf-file-browsed", 1);

        ZombifyBuilder.virtualSave();

    });

    $(document).on('change', '.zf-media-uploader .zf-checkbox-format input', function () {
        if (this.checked) {
            var format = $(this).data('format');
            $(this).parent().parent().parent().attr('data-format', format);
        }
    });

    // Sorting the zombofy group Down
    $(document).on('click', '.js-zf-down', function (e) {
        e.preventDefault();

        ZombifyBuilder.sort($(this).closest(".zombify_group"), 'down');
    });

    // Sorting the zombify group Up
    $(document).on('click', '.js-zf-up', function (e) {
        e.preventDefault();

        ZombifyBuilder.sort($(this).closest(".zombify_group"), 'up');
    });


    // Sorting Quiz Answers
    // $('.zf-answers_container').sortable({});

    $(document).on("change", ".zombify_medatype_radio", function (e) {

        ZombifyBuilder.changeMediaType($(this));

    });

    $(".zombify_quiz").on("change", ":input", function () {

        ZombifyBuilder.updateDependencies(false);

    });

    $(document).on("input", ".zombify_quiz :input[data-embed-url='1']", function () {

        $(this).closest(".zf-embed").find(".zf-embed-video").html("");

        var videoObj = parseEmbedURL($(this), $(this).val(), '100%', 500, $(this).attr("data-embed-sources"), 1);

        $(this).closest(".zf-embed").find(".zf-embed-video").html(videoObj.html);

        $(this).parents('.zf-form-group').removeClass('zf-error');

        if( videoObj.html == '' && $(this).val() !== '' ) {

            $(this).parents('.zf-form-group').addClass('zf-error');

        }
        if( videoObj.type === 'facebook' ) {

            facebookEmbedScript();

        }

        if( videoObj.type == 'mp4' ){

            var video = $(this).closest(".zf-embed").find(".zf-embed-video").find("video");

            window.ZFMediaElementPlayer = new MediaElementPlayer(video);

        }

    });

    $(".zombify_embed_url_textarea").each(function(){

        $(this).closest(".zf-embed").find(".zf-embed-video").html("");

        var videoObj = parseEmbedURL($(this), $(this).val(), '100%', 500, $(this).attr("data-embed-sources"), 1);

        $(this).closest(".zf-embed").find(".zf-embed-video").html(videoObj.html);

    });

    $(document).on("input", ".zombify_embed_url_textarea", function () {

        $(this).closest(".zf-embed").find(".zf-embed-video").html("");

        var videoObj = parseEmbedURL($(this), $(this).val(), '100%', 500, $(this).attr("data-embed-sources"), 1);

        $(this).closest(".zf-embed").find(".zf-embed-video").html(videoObj.html);

        $(this).parents('.zf-form-group').removeClass('zf-error');

        if( videoObj.html == '' && $(this).val() !== '' ) {

            $(this).parents('.zf-form-group').addClass('zf-error');

        }

        if( videoObj.type === 'facebook' ) {

            facebookEmbedScript();

        }

    });

    $(document).on("change", ".zombify_quiz .zf-uploader :input[type='file']", function () {

        var container = $(this).closest("label");

        if (this.files && this.files[0]) {

            if ($(this).prop("multiple") == false) {

                $(this).closest(".zf-form-group").find(".zombify_uploaded_image_item").remove();

            }

            var reader = new FileReader();
            var extension = this.files[0].name.split('.').pop().toLowerCase();

            reader.onload = function (e) {

                if( extension === 'mp4' ) {
                    $(container).find(".zf-preview-gif-mp4").find('source').attr('src', e.target.result);
                    $(container).find(".zf-preview-gif-mp4").show();

                    $(container).find(".gif-video-wrapper:not(.zf-preview-gif-mp4)").each(function () {
                        $(this).hide()
                    });

                    $(container).find(".zf-preview-gif-mp4").find('video')[0].load();
                    $(container).find(".zf-preview-gif-mp4").find('video')[0].play();
                } else {
                    $(container).find(".gif-video-wrapper:not(.zf-preview-img)").each(function () {
                        $(this).hide()
                    });
                    $(container).find(".zf-preview-img").attr('src', e.target.result).show();
                }
                $(container).closest(".zf-uploader").addClass("zf-uploader-uploaded");

                ZombifyBuilder.updateShowDependency();

            }

            reader.readAsDataURL(this.files[0]);
        }

    });


    // Image Start
    $(document).on('click', ".zf-uploader .zf-start-submit_url", function (e) {
        var url = $(this).parent().find('.zf-start-image_url').val();
        if(url) {
            $('.zf-after-start .zf-image_url').val(url);
            $('.zf-after-start .zf-submit_url').trigger('click');
            $(this).parents('.zf-start').removeClass("zf-open");
        } else {
            $(this).parents('.zf-uploader').find('.zf-get-url-popup').removeClass('zf-open');
        }

    });

    $(document).on("change", ".zf-after-start .zf-uploader :input[type='file']", function () {
        $('.zf-start.zf-open').removeClass('zf-open');
    });

    $(document).on('change', '.js-zf-answer-format input', function () {
        if (this.checked) {
            var format = $(this).data('format');
            $(this).parent().parent().next('.zf-answers-box').attr('data-format', format);
        }
    });

    $('.js-zf-answer-format input:checked').each(function () {

        var format = $(this).data('format');
        $(this).parent().parent().next('.zf-answers-box').attr('data-format', format);

    });


    $(".zombify_quiz").on("change", "input", function () {

        ZombifyBuilder.updateShowDependency();

    });

    $(".zombify-trivia-quiz").on("change", "[data-zombify-field-path='questions/answers/correct']", function () {

        if ($(this).prop("checked") == true) {

            $(this).closest(".zf-answers_container").find("[data-zombify-field-path='questions/answers/correct']").prop("checked", false);

            $(this).prop("checked", true);

        }

    });

    $(document).on("change", "[data-zombify-field-path='story/trivia/questions/answers/correct']", function () {

        if ($(this).prop("checked") == true) {

            $(this).closest(".zf-answers_container").find("[data-zombify-field-path='story/trivia/questions/answers/correct']").prop("checked", false);

            $(this).prop("checked", true);

        }

    });

    // Story add Component toggle
    $(document).on('click', '.zf-js-components_toggle', function (e) {
        e.preventDefault();
        if ($(this).parent().hasClass('zf-open')) {
            $(this).parent().removeClass('zf-open')
        } else {
            $(this).parent().addClass('zf-open')
        }
    });

    // add tags plugin (option panel)
    if ($('#tag-editor').length) {
        $('#tag-editor').tagEditor({
            placeholder: $('#tag-editor').attr("placeholder"),
            maxTags: $('#tag-editor').attr("data-count-limit"),
            autocomplete: {
                delay: 0,
                position: {collision: 'flip'}, // automatic menu position up/down
                source: zf_back.ajaxurl + '?action=zombify_get_tags'
            },
            forceLowercase: false
        });

    }

    // wysiwyg plugin
    $('.zf-wysiwyg-advanced').froalaEditor(zf_wysiwyg_config_advanced)
        .on('froalaEditor.image.beforeUpload', function (e, editor, images) {
            toggleDisabledButton('add');
        })
        .on('froalaEditor.image.uploaded', function (e, editor, response) {
            toggleDisabledButton('remove');
        })
        .on('froalaEditor.image.error', function (e, editor, error, response) {
            toggleDisabledButton('remove');

            if (error.code == 5) {
                var $popup = editor.popups.get('image.insert');
                var $layer = $popup.find('.fr-image-progress-bar-layer');

                $layer.find('h3').html(zf_back.zf_max_upload_message);
            }
        });

    $('.zf-wysiwyg-light').froalaEditor(zf_wysiwyg_config_light)
        .on('froalaEditor.image.beforeUpload', function (e, editor, images) {
            toggleDisabledButton('add');
        })
        .on('froalaEditor.image.uploaded', function (e, editor, response) {
            toggleDisabledButton('remove');
        })
        .on('froalaEditor.image.error', function (e, editor, error, response) {
            toggleDisabledButton('remove');
        });

    $('.zf-result-wysiwyg-light.active').froalaEditor(zf_wysiwyg_config_light)
        .on('froalaEditor.image.beforeUpload', function (e, editor, images) {
            toggleDisabledButton('add');
        })
        .on('froalaEditor.image.uploaded', function (e, editor, response) {
            toggleDisabledButton('remove');
        })
        .on('froalaEditor.image.error', function (e, editor, error, response) {
            toggleDisabledButton('remove');
        });


    // add editor on result description field after click
    $(document).on('click', '.zf-result-wysiwyg-light', function (e) {
        e.preventDefault();
        e.stopPropagation();

        var _that = $(this);

        _that.animate(
            { height: parseInt(zf_back.zf_editor_settings.zf_editor_lt_height) + 45 },
            500,
            function() {
                setTimeout(function(){ _that.froalaEditor(zf_wysiwyg_config_light); }, 500);
            }
        );
    });


    $('.zf-multiple-select').zombifyMultiSelect();

    ZombifyBuilder.updateShowDependency();
    ZombifyBuilder.updateDependencies(true);

    // Validating inputs

    //ZombifyBuilder.validateFields();


    /** URL field validation must contain http:// */
    $(document).on("change", "input[zf-validation-url]", function(){
       var url = $(this).val();
       if (!/^https?:\/\//i.test(url) && url !='') {
           url = 'http://' + url;
       }
       $(this).val(url);
    });

    $(document).on("change",".zf-preface-excerpt-cont input[name='zombify[use_preface]']", function () {

        if ($(this).prop("checked") == true) {

            $(this).parents('.zf-preface-excerpt-cont').siblings('.zf-preface').addClass('zf-open');
        } else {
            $(this).parents('.zf-preface-excerpt-cont').siblings('.zf-preface').removeClass('zf-open');
        }

    });

    $(document).on("change",".zf-preface-excerpt-cont input[name='zombify[use_excerpt]']", function () {

        if ($(this).prop("checked") == true) {

            $(this).parents('.zf-preface-excerpt-cont').siblings('.zf-excerpt').addClass('zf-open');
        } else {
            $(this).parents('.zf-preface-excerpt-cont').siblings('.zf-excerpt').removeClass('zf-open');
        }

    });


    zf_video_upload_func();

    $(document).on("click", ".zf_discard_virtual", function(){

        if( window.confirm(zf_back.translatable["confirm_discard_virtual"]) ){

            var quiz_type = $(".zombify_quiz_type").val();

            toggleDisabledButton('add');

            jQuery.ajax({
                url: zf_back.ajaxurl,
                type: 'GET',
                data: {action: 'zombify_discard_virtual', type: quiz_type},
                dataType: 'json',
                success: function (data) {

                    toggleDisabledButton('remove');

                    if( typeof data.result != 'undefined' && data.result == 1 ){

                        window.location.reload();

                    }

                }
            });

        }

    });

    zf_autosave_virtual();

    $(".zf_media_player").each(function(){

        $(this).mediaelementplayer({
            alwaysShowControls: true
        });

    });

    // Hide old zombify shortcode from froala text view
    if( $('.fr-element').length > 0 ) {
        var zombify_preface_content = $('textarea[name="zombify[preface_description]"]').siblings('.fr-box').find('.fr-element').html();

        zombify_preface_content = zombify_preface_content.replace('<p>[zombify_post]</p>','<p class="zf-hide-shortcode">[zombify_post]</p>');

        $('textarea[name="zombify[preface_description]"]').siblings('.fr-box').find('.fr-element').html( zombify_preface_content );
    }

    $('.zf-preview-video-block').on('click', function(e) {
        e.preventDefault();
    });

    $('.zf-preview-video-block').each(function(){
        var _this = $(this);

        _this.hover(function() {
            _this.parents('.zf-uploader').addClass('zf-uploader-on-progress');
        }, function() {
            _this.parents('.zf-uploader').removeClass('zf-uploader-on-progress');
        });
    });

});


function zombify_makeid()
{
    var text = "";
    var possible = "abcdefghijklmnopqrstuvwxyz0123456789";

    for( var i=0; i < 10; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}

function zf_video_upload_func(){

    jQuery(".zf-video-upload").each(function(){

        if( jQuery(this).attr("data-zf-resumable") != 1 && jQuery(this).parents('.zf-erase-before-save').length == 0 ) {

            jQuery(this).attr("data-zf-resumable", "1");

            var unid = zombify_makeid();
            jQuery(this).attr("data-zombify-field-unique", unid);
            jQuery(this).closest(".zf-uploader").find("input[data-zombify-field-path='" + jQuery(this).attr("data-zombify-field-path") + "']").attr("data-zombify-field-unique", unid);

            var n = zombify_video_upload.length;
            var field_path = jQuery(this).attr("data-zombify-field-path");
            var quiz_type = jQuery(".zombify_quiz_type").val();
            var object_index = unid;
            var progressBar = new ProgressBar(jQuery(this).closest('.zf-uploader').find('.zf-progressbar'));
            var that = jQuery(this)

            zombify_video_upload[object_index] = new Resumable({
                target: zf_back.ajaxurl,
                query: {field_path: field_path, unid: unid, action: 'zombify_video_upload'},
                uploadMethod: 'POST',
                quiz_type: quiz_type,
                maxFiles: 1,
                chunkSize: zf_back.chunkSize
            });

            zombify_video_upload[object_index].assignBrowse(jQuery(this));

            zombify_video_upload[object_index].on('fileSuccess', function (file, data) {

                toggleDisabledButton('remove');

                data = JSON.parse(data);

                if (typeof data.result != 'undefined' && data.result == 1) {

                    jQuery("input[data-zombify-field-path='" + data.field_path + "'][data-zombify-field-unique='" + data.unid + "']").val(data.attachment_id);
                    jQuery("input[data-zombify-field-path='" + data.field_path + "'][data-zombify-field-unique='" + data.unid + "']").attr("data-zf-media-id", data.attachment_id);

                    zombify_virtual_unsaved_form = true;

                    progressBar.finish();

                    setTimeout(function () {

                        that.parents('.zf-uploader').find('.zf-preview-video-block').hide();
                        that.parents('.zf-uploader').addClass('zf-uploader-uploaded');
                        that.parents('.zf-uploader').next('.zf-file-info').hide();
                        that.parents('.zf-uploader').find('.zf-video-player-preview').prop('src', data.file_url);

                        var video = that.parents('.zf-uploader').find('.zf-video-player-preview');

                        if (that.parents('.zf-uploader').find('div.zf-video-player-preview').length === 0) {
                            window.ZFMediaElementPlayer = new MediaElementPlayer(video, {
                                success: function (player) {
                                    that.parents('.zf-uploader').find('.zf-video-player-preview').show();
                                }
                            });
                        } else {
                            that.parents('.zf-uploader').find('.zf-video-player-preview').show();
                        }

                    }, 1000);

                    ZombifyBuilder.virtualSave();

                } else {

                    progressBar.finish();

                    jQuery('.zf-preview-video-block').hide();

                    if (typeof data.errorMessage != 'undefined' && data.errorMessage != '') {

                        alert(data.errorMessage);

                    } else
                        alert(zf_back.translatable["incorrect_file_upload"]);

                }

            });

            zombify_video_upload[object_index].on('fileAdded', function (file, event) {

                var validFile = 1;

                toggleDisabledButton('add');

                var exts = jQuery("input[data-zombify-field-path='" + this.getOpt("query").field_path + "'][data-zombify-field-unique='" + this.getOpt("query").unid + "']").attr("zf-validation-extensions");
                var valid_extensions = exts.split(",");

                for (j = 0; j < valid_extensions.length; j++) {
                    valid_extensions[j] = valid_extensions[j].trim();
                }

                var nm = file.fileName;

                var file_ext = nm.substr(nm.lastIndexOf('.') + 1);
                file_ext = file_ext.toLowerCase();

                if (!ZombifyBuilder.inArray(file_ext, valid_extensions)) {

                    validFile = 2;

                }

                var maxsize = jQuery("input[data-zombify-field-path='" + this.getOpt("query").field_path + "'][data-zombify-field-unique='" + this.getOpt("query").unid + "']").attr("zf-validation-maxsize");

                if( maxsize < file.size ){

                    validFile = 3;

                }

                var parentDiv = jQuery("input[data-zombify-field-path='" + this.getOpt("query").field_path + "'][data-zombify-field-unique='" + this.getOpt("query").unid + "']").closest(".zf-uploader");

                switch( validFile ){

                    case 1:

                        parentDiv.find('.zf-preview-video-block').show();

                        progressBar.fileAdded();

                        zombify_video_upload[object_index].upload();

                        break;

                    case 2:

                        var errMsg = zf_back.translatable['invalid_file_extension'] + ' ' + $("input[data-zombify-field-path='" + this.getOpt("query").field_path + "'][data-zombify-field-unique='" + this.getOpt("query").unid + "']").attr("zf-validation-extensions");

                        if (parentDiv.find(".zf-help").length > 0) {
                            parentDiv.find(".zf-help").html(errMsg);
                        } else {
                            parentDiv.append('<span class="zf-help">' + errMsg + '</span>');
                        }

                        break;

                    case 3:

                        var errMsg = zf_back.translatable['invalid_file_size'] + ' ' + Math.round( parseInt($("input[data-zombify-field-path='" + this.getOpt("query").field_path + "'][data-zombify-field-unique='" + this.getOpt("query").unid + "']").attr("zf-validation-maxsize"))/1024/1024 )+zf_back.translatable['mb'];

                        if (parentDiv.find(".zf-help").length > 0) {
                            parentDiv.find(".zf-help").html(errMsg);
                        } else {
                            parentDiv.append('<span class="zf-help">' + errMsg + '</span>');
                        }

                        break;

                }

            });


            zombify_video_upload[object_index].on('progress', function () {

                progressBar.uploading(zombify_video_upload[object_index].progress() * 100);

            });

            zombify_video_upload[object_index].on('fileError', function (file, message) {
                toggleDisabledButton('remove');
                console.debug('fileError', file, message);
                alert(zf_back.translatable["incorrect_file_upload"]);
            });

            zombify_video_upload[object_index].on('error', function (message, file) {
                toggleDisabledButton('remove');
                console.debug('error', message, file);
                alert(zf_back.translatable["incorrect_file_upload"]);
            });

            jQuery('.zf-progress-cancel-btn').on('click', function () {

                toggleDisabledButton('add');

                n = zombify_video_upload[object_index].files.length;

                for (var i = 0; i < n; i++) {

                    var unid = zombify_video_upload[object_index].files[i].uniqueIdentifier;

                    if (unid == '') continue;

                    jQuery.ajax({
                        url: zf_back.ajaxurl,
                        type: 'GET',
                        data: {cancel: 1, action: 'zombify_video_upload', uniqueIdentifier: unid},
                        dataType: 'json',
                        success: function (data) {
                            toggleDisabledButton('remove');
                        }
                    });

                }
                zombify_video_upload[object_index].cancel();


                jQuery(this).parents('.zf-preview-video-block').hide();
            });

        }

    });

}

function ProgressBar(element) {
    this.fileAdded = function() {
        jQuery(element).find('.zf-progressbar-active').css('width','0%');
    },

    this.uploading = function(progress) {
        jQuery(element).find('.zf-progressbar-active').css('width', progress + '%');
    },

    this.finish = function() {
    }
}



function zombify_submit_process( perc ){

    $(".zf-image-preview-block").each(function(){

        if( $(this).closest(".zf-uploader").find("input[data-zombify-field-type='file']").attr("data-zf-file-browsed") == 1 ){

            $(this).show();

            var progressBar = new ProgressBar($(this).find(".zf-progressbar"));
            progressBar.fileAdded();
            progressBar.uploading(perc > 99 ? 99 : perc);

            if( perc >= 100 ){

                $(this).addClass("zf_remove_progress");

                progressBar.finish();

            }
        }


    });

}

function zf_autosave_virtual(){


    ZombifyBuilder.virtualSave();

    setTimeout("zf_autosave_virtual();", zombify_virtual_save_interval);

}

jQuery.fn.zombifyMultiSelect = function () {

    return this.each(function () {

        var $this = jQuery(this),
            selectedLabel = '',
            selected = [],
            limit = zf_back.zf_category_select_limit;

        $this.find('.zf-select_header').on('click',function(e){
            $this.toggleClass('zf-active');
        });
        $this.on('click',function(e){
            e.stopPropagation();
        });
        jQuery('body').on('click',function(e){
            $this.removeClass('zf-active');
        });

        var init = function(){
            selected = [];
            selectedLabel = '';
            if($this.find('input[type="checkbox"]:checked').length) {
                $this.find('input[type="checkbox"]:checked').each(function(){
                    var label = jQuery(this).data('label');
                    selected.push(label);
                });
                for(var i = 0; i < selected.length; i++) {
                    if( i + 1 ==  selected.length ) {
                        selectedLabel += selected[i];
                    } else {
                        selectedLabel += selected[i]+ ', ';
                    }
                    $this.find('.zf-selected').html(selectedLabel)
                }
            } else {
                $this.find('.zf-selected').html($this.find('.zf-select_header').data('label'))
            }
        };

        init();

        $this.find('input[type="checkbox"]').on('change',function(e){

            if( limit === '1' ) {

                if( jQuery(this).prop("checked") === false ) {
                    $this.find('input[type="checkbox"]').prop('checked', false);
                } else {
                    $this.find('input[type="checkbox"]').prop('checked', false);
                    jQuery(this).prop("checked", true)
                }

                jQuery(this).parents('.zf-multiple-select').removeClass('zf-active');

            } else {

                if (jQuery(this).prop("checked") == true && $this.find('input[type="checkbox"]:checked').length >= limit) {
                    $this.find('input[type="checkbox"]').attr('disabled', true);
                    $this.find('input[type="checkbox"]:checked').attr('disabled', false);
                } else {
                    $this.find('input[type="checkbox"]').attr('disabled', false);
                }

            }

            init();

        });

    });
};

function toggleDisabledButton( $toggle ) {
    if( $toggle === 'add' ) {
        jQuery('.zf-fixed-bottom-pane').find('.zombify_save').addClass('zf-disabled');
        jQuery('.zf-fixed-bottom-pane').find('.zf_discard_virtual').addClass('zf-disabled');
        jQuery('.zf-fixed-bottom-pane').find('.zombify_preview').addClass('zf-disabled');
        jQuery('.zf-fixed-bottom-pane').find('.zombify_publish').addClass('zf-disabled');
    } else if( $toggle === 'remove' ) {
        jQuery('.zf-fixed-bottom-pane').find('.zombify_save').removeClass('zf-disabled');
        jQuery('.zf-fixed-bottom-pane').find('.zf_discard_virtual').removeClass('zf-disabled');
        jQuery('.zf-fixed-bottom-pane').find('.zombify_preview').removeClass('zf-disabled');
        jQuery('.zf-fixed-bottom-pane').find('.zombify_publish').removeClass('zf-disabled');
    }
}


function zf_get_video_by_url( obj ){

    var url = $(obj).parent().find('.zf-image_url').val();

    if(url) {
        if( url.split('.').pop() === 'mp4' ) {
            $(obj).parents('.zf-uploader').find(".zf-preview-gif-mp4").find('source').attr('src', url);
            $(obj).parents('.zf-uploader').find(".zf-preview-gif-mp4").show();
            $(obj).parents('.zf-uploader').find(".zf-preview-gif-mp4").find('video')[0].load();
            $(obj).parents('.zf-uploader').find(".zf-preview-gif-mp4").find('video')[0].play();
        } else {
            $(obj).parents('.zf-uploader').find(".zf-preview-img").attr('src', url).show();
        }

        $(obj).closest(".zf-embed").find(".zf-embed-video").html("");

        var videoObj = parseEmbedURL($(obj).parent().find('.zf-image_url'), $(obj).parent().find('.zf-image_url').val(), '100%', 500, 'youtube,mp4', 1);

        $(obj).closest(".zf-embed").find(".zf-embed-video").html(videoObj.html);

        $(obj).parents('.zf-form-group').removeClass('zf-error');

        if( videoObj.html == '' && $(obj).val() !== '' ) {

            $(obj).parents('.zf-form-group').addClass('zf-error');

        }

        if( videoObj.type == 'mp4' ){

            var video = $(obj).closest(".zf-embed").find(".zf-embed-video").find("video");

            window.ZFMediaElementPlayer = new MediaElementPlayer(video, {
                success: function(player) {
                    //jQuery('.zf-video-player-preview').show();
                }
            });

        }

        $(obj).parents('.zf-uploader').find('.zf-get-url-popup').removeClass('zf-open');
        $(obj).parents('.zf-uploader').addClass("zf-uploader-uploaded");

    } else {
        $(this).parents('.zf-uploader').find('.zf-get-url-popup').removeClass('zf-open');
    }

}

function IsJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}