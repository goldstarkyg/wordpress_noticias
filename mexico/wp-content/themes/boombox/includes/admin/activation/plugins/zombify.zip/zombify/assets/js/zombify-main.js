jQuery(document).ready(function ($) {
	// Zombify popup open / close
	$(document).on('click', '.zf-create-popup', function (e) {
	    e.preventDefault();
	    $('.zombify-create-popup').addClass('zf-open');
	});

	$(document).on('click', '.zombify-create-popup .zf-popup_close', function (e) {
	    e.preventDefault();
	    $('.zombify-create-popup').removeClass('zf-open');
	});

	// worked only for Boombox (close create popup for opening authentication popup (in boombox))
	$(document).on('click', '.js-authentication', function (e) {
	    e.preventDefault();
	    $('.zombify-create-popup').removeClass('zf-open');
	});

	$(document).on('click', '.zombify-submit-popup .zf-popup_close', function (e) {
	    e.preventDefault();
	    $('.zombify-submit-popup').removeClass('zf-open');
	});


	// submission page single post  actions Toggle
	$(document).on('click', '.js-zf-actions-toggle', function (e) {
	    e.preventDefault();
	    e.stopPropagation();
	    $(this).parent().toggleClass('zf-open');
	});
	$(document).on('click', 'body', function () {
	    $('.zf-actions.zf-open').removeClass('zf-open');
	});

	//Buddypress filter
	$('#submissions-filter-by').change(function () {
	    var select = $(this).val();
	    if (select == -1) {
	        $('.zf-submission .zf-post').show();
	    } else if ($('.zf-submission .zf-post.zf-type-' + select).length) {
	        $('.zf-submission .zf-post').show();
	        $('.zf-submission .zf-post').hide();
	        $('.zf-submission .zf-post.zf-type-' + select).show();
	    }

	});
});