<article style="height:250px;" class="post post-636 type-post status-publish format-standard has-post-thumbnail hentry category-animals category-photography tag-animals reaction-cute reaction-lol">

    <?php the_title(); ?>

</article>