=== QSNoticias ===
Author: GAREY Agencia Web
Author URI: http://garey.mx
Requires at least: WordPress 4.1
Tested up to: WordPress 4.5.2
Theme URI: http://garey.mx
Version: 1.8.0
License: GNU General Public License v2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: light, one-column, two-columns, three-columns, left-sidebar, right-sidebar, flexible-header, fluid-layout, responsive-layout, blavatar, custom-colors, custom-header, custom-menu, editor-style, featured-images, featured-image-header, post-formats, sticky-post, theme-options, translation-ready, photoblogging


== Description ==
Desarrollado para QSNoticias

== Installation ==

La instalación esta dada y brindado por GAREY Agencia Web
